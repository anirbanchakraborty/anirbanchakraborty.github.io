function [sampled_points] = downsample(points, dimension, sampling_frequency)

%% Anirban Chakraborty, Electrical Engineering, University of California, Riverside.

points = sortrows(points, dimension);
sampled_points = points(1:sampling_frequency:end, :);

return;